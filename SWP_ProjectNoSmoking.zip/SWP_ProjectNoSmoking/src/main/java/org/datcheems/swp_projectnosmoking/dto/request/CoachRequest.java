package org.datcheems.swp_projectnosmoking.dto.request;

import lombok.Data;

@Data
public class CoachRequest {
    private String username;
    private String email;
    private String fullName;
}

package org.datcheems.swp_projectnosmoking.dto.request;

import lombok.Data;

@Data
public class PasswordResetRequest {
    private String email;
}
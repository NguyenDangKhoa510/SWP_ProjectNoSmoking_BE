package org.datcheems.swp_projectnosmoking.entity;

public enum BlogStatus {
    PENDING,
    APPROVED,
    REJECTED
}

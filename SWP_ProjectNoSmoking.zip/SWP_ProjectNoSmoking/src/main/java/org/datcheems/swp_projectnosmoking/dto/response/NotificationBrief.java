package org.datcheems.swp_projectnosmoking.dto.response;

import lombok.Data;

@Data
public class NotificationBrief {
    private Long id;
    private String title;

}

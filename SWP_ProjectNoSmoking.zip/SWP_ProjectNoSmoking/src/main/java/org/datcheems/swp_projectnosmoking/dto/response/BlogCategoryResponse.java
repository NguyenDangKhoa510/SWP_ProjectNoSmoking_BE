package org.datcheems.swp_projectnosmoking.dto.response;

import lombok.Data;

@Data
public class BlogCategoryResponse {
    private Long id;
    private String name;
}

package org.datcheems.swp_projectnosmoking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwpProjectNoSmokingApplicationTests {

	@Test
	void contextLoads() {
	}

}
